# GoogleMap_AddressView
On long click on map shows the address of the place
